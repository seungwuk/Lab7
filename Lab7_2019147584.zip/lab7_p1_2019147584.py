import re

def find_function_definitions_and_calls(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    functions = {}
    function_def_pattern = re.compile(r'^\s*def\s+(\w+)\(')
    function_call_pattern = re.compile(r'\b(\w+)\s*\(')

    for line_num, line in enumerate(lines, start=1):
        def_match = function_def_pattern.search(line)
        if def_match:
            func_name = def_match.group(1)
            functions[func_name] = {'def': line_num, 'calls': []}

    for line_num, line in enumerate(lines, start=1):
        call_matches = set(function_call_pattern.findall(line))
        for call in call_matches:
            if call in functions and functions[call]['def'] != line_num:
                functions[call]['calls'].append(line_num)

    for func_name, details in functions.items():
        print(f"{func_name}: def in {details['def']}, calls in {sorted(details['calls'])}")

find_function_definitions_and_calls("input_7_1.txt")
