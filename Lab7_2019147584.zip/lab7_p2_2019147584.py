import re

def count_and_sort_alphabets(file_path):
    alphabet_counts = {}

    with open(file_path, 'r') as file:
        text = file.read()

    letters = re.findall(r'[a-zA-Z]', text)
    
    for letter in letters:
        upper_letter = letter.upper()
        alphabet_counts[upper_letter] = alphabet_counts.get(upper_letter, 0) + 1

    items = list(alphabet_counts.items())
    items.sort(key=lambda x: x[1], reverse=True)
    sorted_alphabets = [item[0] for item in items]

    print(sorted_alphabets)

count_and_sort_alphabets("input_7_2.txt")
